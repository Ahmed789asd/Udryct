/*CMD
  command: /start
  help:
  need_reply: false
  auto_retry_time:
  folder:
  answer: اختار من الازرار :👇🏻
  keyboard:  تفعيل نقاط التشغيل ☄︎ ,\n  الرصيد أو الشحن ⛁ ,سجل حساباتي ⎙ ,\n لوحة المتصدرين ☃︎ , الدعم الفني ☏  ,\n التعليمات والشروط 𓍝 , تغير اللغه ⌨ ,\n  نظام الربح ✉
  aliases:
  group:
CMD*/

const WELCOME_MSG = "☺︎ **أهلاً بك في بوت شحن نقاط التشغيل!**\n\n";
const REF_POINTS = 2;

// منع المستخدم من الضغط على رابطه الشخصي
function onTouchOwnLink() {
  Bot.sendMessage("⚠︎ لا يمكنك استخدام رابط الدعوة الخاص بك.");
}

// عند نجاح جلب إحالة جديدة
function onAttracted(refUser) {
  if (!refUser || !refUser.telegramid) { return; }

  // إضافة نقاط لصاحب الدعوة تلقائياً
  Libs.ResourcesLib.anotherUserRes("point", refUser.telegramid).add(REF_POINTS);

  // إرسال رسالة ترحيب للشخص الجديد
  Bot.sendMessage(WELCOME_MSG + "✉ تم استضافتك عبر رابط دعوة صديق بنجاح!");

  // إشعار الشخص الداعي بأن رصيده زاد
  Bot.sendMessageToChatWithId(
    refUser.telegramid,
    "✿ **مبروك! انضم شخص جديد عبر رابط إحالتك.**\n\n تمت إضافة: **+" + REF_POINTS + " ⛁** لرصيدك بنجاح ☄︎"
  );
}

// تشغيل نظام تتبع الإحالات
RefLib.track({
  onTouchOwnLink: onTouchOwnLink,
  onAttracted: onAttracted,
  debug: false
});

// التأكد الآمن من توليد رابط الإحالة للمستخدم الحالي
if (!RefLib.getRefLink()) {
  try {
    RefLib.generateLink();
  } catch (e) {
    // تجاهل أي خطأ في توليد الرابط، المستخدم هيقدر يحاول تاني لما يفتح /invite_friends
  }
}

// تسجيل المستخدم في لوحة المتصدرين
Libs.TopUsersLib.register(user.telegramid);

// رسالة الترحيب العامة لو دخل مباشرة (وليست ضغطة زر Callback)
if (!request.data) {
  Bot.sendMessage(WELCOME_MSG + "⌨ اختر من الأزرار بالأسفل لبدء الاستخدام.");
}
