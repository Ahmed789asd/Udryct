/*CMD
  command: /promo_code
  help:
  need_reply: false
  auto_retry_time:
  folder:

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases:
  group:
CMD*/

Libs.MaintenanceLib.send();
