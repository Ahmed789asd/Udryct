/*CMD
  command: Change_language
  help:
  need_reply: false
  auto_retry_time:
  folder:

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: تغير اللغه ⌨
  group:
CMD*/

Libs.MaintenanceLib.send();
