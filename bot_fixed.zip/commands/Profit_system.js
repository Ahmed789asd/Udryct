/*CMD
  command: Profit_system
  help:
  need_reply: false
  auto_retry_time:
  folder:

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: نظام الربح ✉
  group:
CMD*/

Libs.MaintenanceLib.send();
