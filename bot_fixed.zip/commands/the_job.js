/*CMD
  command: the_job
  help:
  need_reply: false
  auto_retry_time:
  folder:

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: تفعيل نقاط التشغيل ☄︎
  group:
CMD*/

// جلب رصيد الـ point للمستخدم الحالي باستخدام النظام بتاعنا
let pts = Libs.ResourcesLib.userRes("point");

let buttons = Libs.CountriesLib.buildKeyboard("/save_country", "/cancel");

let textMsg = "❍ **اختر الدولة التي تريد تفعيل نقاط التشغيل فيها:**\n\n" +
              "$ **رصيدك الحالي:** " + pts.value().toFixed(0) + " ⛁\n" +
              "⦿ **تكلفة التفعيل:** 3 ⛁\n\n" +
              "☟ اضغط على الدولة للمتابعة:";

let isCallback = request && request.message && request.message.message_id;

if (isCallback) {
  Api.editMessageText({
    message_id: request.message.message_id,
    text: textMsg,
    reply_markup: { inline_keyboard: buttons },
    parse_mode: "Markdown"
  });
} else {
  Api.sendMessage({
    text: textMsg,
    reply_markup: { inline_keyboard: buttons },
    parse_mode: "Markdown"
  });
}
