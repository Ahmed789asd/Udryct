/*CMD
  command: My_account_log
  help:
  need_reply: false
  auto_retry_time:
  folder:

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: سجل حساباتي ⎙
  group:
CMD*/

Libs.MaintenanceLib.send();
